/**
 * loops.cpp
 *
 * EECS 183, Winter 2017
 * Lab 4: Loops exercises
 *
 * <#Name(s)#>
 * <#uniqname(s)#>
 *
 * <#A description of the assignment here#>
 */

#include "loops.h"
#include <iostream>

using namespace std;


void print_rectangle(int rows, int cols) {
    // TODO - implement
    
}

void print_right(int n) {
    // TODO - implement
    
}

void print_right_justified(int n) {
    // TODO - implement
    
}