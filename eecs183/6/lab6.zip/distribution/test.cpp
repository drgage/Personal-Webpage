/**
 * test.cpp
 *
 * EECS 183, Winter 2017
 * Lab 6: Classes and File I/O
 *
 * <#Name#>
 * <#uniqname#>
 *
 * <#Description#>
 */

#include <iostream>
#include <fstream>
using namespace std;

#include "Point.h"

void test_point();

int main() {
    test_point();

    return 0;
}

void test_point() {
    Point pt1;
    
    pt1.setX(15);
    
    cout << "pt1 is: " << pt1 << endl;
    
    ifstream input_file;
    input_file.open("data1.txt");
    pt1.read(input_file);
    cout << "pt1 is: " << pt1 << endl;
  
    return;
}
