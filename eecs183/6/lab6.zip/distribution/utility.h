/**
 * utility.h
 *
 * EECS 183, Winter 2017
 * Lab 6: Classes and File I/O
 * Taken from Project 4: CoolPics
 *
 * declares DIMENSION.
 */


#ifndef P4_cool_pics_utility_h
#define P4_cool_pics_utility_h

// Image is 100 x 100
const static int DIMENSION = 100;



#endif
