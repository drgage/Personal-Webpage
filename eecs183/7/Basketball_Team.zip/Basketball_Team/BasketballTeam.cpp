//
//  BasketballTeam.cpp
//  Basketball_Team
//
//  Created by Diana Gage on 3/15/17.
//  Copyright (c) 2017 Diana Gage. All rights reserved.
//

#include <iostream>
#include <string>
#include "BasketballTeam.h"
using namespace std;

BasketballTeam::BasketballTeam() {
    num_wins = 0;
    num_losses = 0;
    
    for (int i = 0; i < NUM_PLAYERS; ++i) {
        player_numbers[i] = 0;
        player_names[i] = "";
    }
}

BasketballTeam::BasketballTeam(int num_wins_in, int num_losses_in,
                               int player_nums_in[NUM_PLAYERS],
                               string player_names_in[NUM_PLAYERS]) {
    num_wins = num_wins_in;
    num_losses = num_losses_in;
    
    for (int i = 0; i < NUM_PLAYERS; ++i) {
        player_numbers[i] = player_nums_in[i];
        player_names[i] = player_names_in[i];
    }
}

void BasketballTeam::update_record(bool won) {
    if (won) {
        ++num_wins;
    }
    else {
        ++num_losses;
    }
}

int BasketballTeam::get_num_wins() {
    return num_wins;
}

int BasketballTeam::get_num_losses() {
    return num_losses;
}

void BasketballTeam::set_player_names(string player_names_in[NUM_PLAYERS]) {
    for (int i = 0; i < NUM_PLAYERS; ++i) {
        player_names[i] = player_names_in[i];
    }
}

void BasketballTeam::print_team(ostream& outs) {
    outs << "NUM WINS: " << num_wins << endl;
    outs << "NUM LOSSES: " << num_losses << endl;
    
    outs << "PLAYER NAMES AND NUMBERS: " << endl;
    for (int i = 0; i < NUM_PLAYERS; ++i) {
        outs << "Player " << player_numbers[i] << ": " << player_names[i]
        << endl;
    }
}







