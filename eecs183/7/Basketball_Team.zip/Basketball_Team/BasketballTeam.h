//
//  BasketballTeam.h
//  Basketball_Team
//
//  Created by Diana Gage on 3/15/17.
//  Copyright (c) 2017 Diana Gage. All rights reserved.
//

#ifndef __Basketball_Team__BasketballTeam__
#define __Basketball_Team__BasketballTeam__

#include <string>
#include <stdio.h>
using namespace std;

const int NUM_PLAYERS = 12;

class BasketballTeam {
private:
    string player_names[NUM_PLAYERS];
    int player_numbers[NUM_PLAYERS];
    int num_wins;
    int num_losses;
    
public:
    BasketballTeam();
    BasketballTeam(int num_wins_in, int num_lossess_in,
                   int player_nums_in[NUM_PLAYERS],
                   string player_names_in[NUM_PLAYERS]);
    void update_record(bool won);
    void print_team(ostream& outs);
    int get_num_wins();
    int get_num_losses();
    void set_player_names(string player_names_in[NUM_PLAYERS]);
};


#endif
