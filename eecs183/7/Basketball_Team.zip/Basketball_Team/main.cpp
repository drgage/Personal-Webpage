//
//  main.cpp
//  Basketball_Team
//
//  Created by Diana Gage on 3/15/17.
//  Copyright (c) 2017 Diana Gage. All rights reserved.
//

#include <iostream>
#include <string>
#include "BasketballTeam.h"
using namespace std;

int main() {
    
    // creating instance using default constructor
    // also could do BasketballTeam Wolverines = BasketballTeam();
    BasketballTeam Wolverines;
    
    int wins = 2;
    int losses = 1;
    int nums[NUM_PLAYERS] = {2, 17, 31, 1, 5, 9, 66, 89, 3, 11, 15, 23};
    string names[NUM_PLAYERS] = {"Diana", "Phoebe", "Paul", "Keegan", "Kevin F",
                                "Alex", "Gabe", "Logan", "Jade", "Mark",
                                "Kevin R", "LeBron"};
    
    // creating instance using non-default constructor
    BasketballTeam Lab(wins, losses, nums, names);
    
    // print our team to standard output (cout)
    Lab.print_team(cout);
    
    // we win a game!
    Lab.update_record(true);
    
    // Let's see our wins now
    cout << "Updated wins: " << Lab.get_num_wins() << endl << endl;
    
    // Let's update the Wolverines (men's team)!
    // current record: 24 wins, 11 losses --> according to Google
    int wolverine_wins = 24;
    int wolverine_losses = 11;
    
    // update wins
    for (int i = 0; i < wolverine_wins; ++i) {
        Wolverines.update_record(true);
    }
    
    // update losses
    for (int i = 0; i < wolverine_losses; ++i) {
        Wolverines.update_record(false);
    }
 
    // Check the Wolverines' record
    cout << "Wolverine wins: " << Wolverines.get_num_wins() << endl;
    cout << "Wolverine losses: " << Wolverines.get_num_losses() << endl;
    
    return 0;
}
