//
//  Person.cpp
//  StayinBlue
//
//  Created by Diana Gage on 11/4/15.
//  Copyright (c) 2015 Diana Gage. All rights reserved.
//

#include <string>
#include <iostream>
#include "Person.h"
#include "Drink.h"
using namespace std;

// constructors
Person::Person() {

}

Person::Person(string name_in, string gender_in, double weight_in) {
    

}

// getters & setters
string Person::get_name() const {

}

string Person::get_gender() const {

}

double Person::get_weight() const {

}

int Person::get_num_drinks() const {

}

double Person::get_BAC() const {

}

int Person::get_minutes_drinking() const {

}

void Person::set_name(string name_in) {

}

void Person::set_gender(string gender_in) {

}

void Person::set_weight(double weight_in) {

}

// member functions
void Person::print_summary() const {

}


void Person::take_drink(const Drink& drink_in) {
    

}

double Person::adjust_BAC() {
    
}


bool Person::in_blue() const {

}
