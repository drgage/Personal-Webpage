//
//  main.cpp
//  StayinBlue
//
//  Created by Diana Gage on 11/4/15.
//  Copyright (c) 2015 Diana Gage. All rights reserved.
//

#include <iostream>
#include <string>
#include "Drink.h"
#include "Person.h"
using namespace std;

int main() {
    
    // Create two instances of Person class, and 3 instances of Drink class
    // Use a default constructor at least once to practice:
    
    
    
    // Declare and initialize variables to represent each instance's BAC:
    
    
    // Have your instances take any number of drinks, and adjust their BACs
    // accordingly
    
    
    // Print the summary for each instance.
    // To make sure you got the right answer, check results with the chart
    // online!
    //
    // For example: if you created a Person instance that is female and weighs
    //              120 lbs, and had the instance take two drinks, check that
    //              the instance's summary gives the correct BAC (0.08)
    

}
