//
//  main.cpp
//  discussion5Challenge Problem
//
//  Created by Erin Donahue on 2/6/16.
//  Copyright © 2016 Erin Donahue. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

/* DEALS WITH:
*    Scope
*    Arrays
*    For Loops
*    If Statements
*    Nesting
*    Pass by Reference
*    Passing Arrays into functions
*
* HINTS:
*    string name = Erin;
*
*    int length = name.length();
*    // length = 4
*
*    string arr[2] = {"Erin", "Preeti"};
*
*    char place = arr[0][0]; 
*    // place = 'E'
*
*    place = arr[1][5];
*    // place = 'i'
*/


/* R: one array, and size of array
 * M: nothing
 * E: For each string in the array, tallies and prints the
 *    number of 'b's found. Also tallies and prints the total
 *    number of 'b's found across all strings
 */
void bCountingFunction_1(string arr[], int size);

/* R: one array, and size of array
 * M: nothing
 * E: For each string in the array, tallies ONLY the
 *    number of 'b's found. Also tallies ONLY the total
 *    number of 'b's found across all strings
 *    The Tallies should be printed in main()
 */
void bCountingFunction_2(string arr[], int size,
                         int& count0,
                         int& count1,
                         int& count2,
                         int& count3,
                         int& count4,
                         int& total_count);

int main() {

    int size = 5;
    string words[5] = {"banana",
                       "bumble",
                       "cat",
                       "abba",
                       "bob and betty beyster"};
    
    
    
    cout << "Regular Version!" << endl;
    
    bCountingFunction_1(words, size);
    
    cout << endl << endl <<"Pass By Reference Version!" << endl << endl;
    
    int count0 = 0;
    int count1 = 0;
    int count2 = 0;
    int count3 = 0;
    int count4 = 0;
    int total_count = 0;
    
    bCountingFunction_2(words, size,
                        count0,
                        count1,
                        count2,
                        count3,
                        count4,
                        total_count);
    
    cout << "String0: " << count0 << endl;
    cout << "String1: " << count1 << endl;
    cout << "String2: " << count2 << endl;
    cout << "String3: " << count3 << endl;
    cout << "String4: " << count4 << endl;
    cout << "Total Count: " << total_count << endl;
    
    
    /* EXPECTED OUTPUT (For Both Versions)
     *
     * String0: 1
     * String1: 2
     * String2: 0
     * String3: 2
     * String4: 4
     * Total Count: 9
     *
     */
    
    return 0;
}

void bCountingFunction_1(string arr[], int size){
    
    /* THINGS TO CONSIDER: 
     *   Double nested for loops
     *   Scope within said for loops
     *   Use cout
     */
    
    int total_count = 0; // outside the loop so it always increases
    
    for (int i = 0; i < 5; i++)
    {
        // inside for loop so it only counts for each string
        int count = 0;
        
        // iterates through the letters of the string
        for (int y = 0; y < arr[i].length(); y++)
        {
            if (arr[i][y] == 'b')
            {
                count++;
                total_count++;
            }
        }
        cout << "String" << i << ": " << count << endl;
    }
    cout << "Total count: " << total_count;
    
    
}

void bCountingFunction_2(string arr[], int size,
                         int& count0,
                         int& count1,
                         int& count2,
                         int& count3,
                         int& count4,
                         int& total_count)
{
    
    /* THINGS TO CONSIDER:
     *   Double nested for loops
     *   for loop and if-else nesting
     *   scope
     *   do NOT use cout until main();
     */
    
    
    for (int i = 0; i < 5; i++) // iterates through the strings
    {
        // iterates through the letters of the strings
        for (int y = 0; y < arr[i].length(); y++)
        {
            if (arr[i][y] == 'b')
            {
                if(i == 0)
                {
                    count0++;
                }
                else if(i == 1)
                {
                    count1++;
                }
                else if(i == 2)
                {
                    count2++;
                }
                else if(i == 3)
                {
                    count3++;
                }
                else
                {
                    count4++;
                }
                
                total_count++;
            }
        }
    }
}
