#include <string>
#include "Dog.h"
using namespace std;

// default constructor
Dog::Dog() {
	size = "";
	color = "";
	age = 0;
}

// non-default/custom constructor
Dog::Dog(string size_in, string color_in, int age_in) {
	size = size_in;
	color = color_in;
	age = age_in;
}

// ** NOTE: this member function is const because it doesn't
// modify any of the private member variables --> it just accesses them!
// (it's a good practice to make functions const that aren't supposed
// to change anything)
string Dog::get_size() const {
	return size;
}

string Dog::get_color() const {
	return color;
}

int Dog::get_age() const {
	return age;
}

// ** NOTE: setters should NOT be declared const because their
// job is to change (set) a private member variable!
void Dog::set_age(int age_in) {
	age = age_in;
}