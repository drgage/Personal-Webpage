#ifndef DOG_H
#define DOG_H
#include <string>
using namespace std;

class Dog {
	
	public:
		Dog();
		Dog(string size_in, string color_in, int age_in);
		string get_size() const;
		string get_color() const;
		int get_age() const;
		void set_age(int new_age);


	private:
		string size;
		string color;
		int age;	

};

#endif