#include "Dog.h"
#include <iostream>
using namespace std;

int main() {

	// can also do Dog buddy = Dog();
	Dog buddy;
	buddy.set_age(5);

	// can also do Dog Airbud = Dog("large", "yellow", 6);
	Dog AirBud("large", "yellow", 6);
	cout << "AirBud is " << AirBud.get_age() << " years old!" << endl;

	// a year has past
	AirBud.set_age(7);
	cout << "Now AirBud is " << AirBud.get_age() << " years old!" << endl;

	// get the color of AirBud
	cout << "AirBud is " << AirBud.get_color() << endl;

	return 0;
}