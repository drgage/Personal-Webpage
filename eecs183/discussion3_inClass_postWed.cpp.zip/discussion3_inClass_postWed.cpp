//
//  discussion3_inClass_preWed.cpp
//  Discussion Challenge Problems
//
//  Created by Leah Bar-On Simmons on 1/24/16.
//  Copyright © 2016 Leah Bar-On Simmons. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>

using namespace std;


const int TUSCANY = 10000;
const int LONDON = 7000;

bool doYouHaveVacationTime();


int main(){
    
    int userMoney = 0;
    
    
    cout << "How much money do you have in $? (round to the nearest whole number)" << endl;
    cin >> userMoney;
    
    bool hasVacationTime = doYouHaveVacationTime();
    
    if (hasVacationTime){
        
        if (userMoney >= TUSCANY){
            cout << "You can travel to Tuscany!" << endl;
        }
        
        else if (userMoney >= LONDON){
            cout << "You can travel to London!" << endl;
        }
        
        else{
            cout << "You should travel somewhere in the US." << endl;
        }
    }
    
    else{
        cout << "Netflix?" << endl;
    }
    
}

bool doYouHaveVacationTime(){
    
    string answer;
    cout << "Do you have vacation time? ";
    cin >> answer;
    
    if (answer == "yes" || answer == "Yes"){
        return true;
    }
    
    return false;
}
